﻿namespace DoseEmDia.Models.Enums
{
    public enum TipoNotificacao
    {
        VacinaAtrasada = 1,
        VacinaVencendo = 2,
        CampanhaImunizacao = 3,
        VacinaOk = 4,
        AvisoGeral = 5
    }
}
