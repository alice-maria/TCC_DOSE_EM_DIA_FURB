﻿namespace DoseEmDia.Models
{
    public class Pais
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Url { get; set; }
    }
}
